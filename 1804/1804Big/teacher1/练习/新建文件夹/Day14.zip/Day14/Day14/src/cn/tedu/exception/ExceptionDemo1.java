package cn.tedu.exception;

public class ExceptionDemo1 {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws CloneNotSupportedException {

		try {
			System.out.println(1 / 0);
		} catch (ArithmeticException e) {
			System.out.println("�����쳣~~~");
		}
		// A a = new A();
		// B b = (B) a;

		// String str = "shag";
		// System.out.println(str.matches("+"));

		// Integer in = new Integer("0x215");
		// System.out.println(in);

		ExceptionDemo1 e1 = new ExceptionDemo1();
		ExceptionDemo1 e2 = (ExceptionDemo1) e1.clone();

	}

}

class A {
}

interface B {
}
