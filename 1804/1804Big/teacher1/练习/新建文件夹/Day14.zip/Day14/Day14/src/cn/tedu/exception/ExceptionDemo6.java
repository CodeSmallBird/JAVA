package cn.tedu.exception;

public class ExceptionDemo6 {

	public static void main(String[] args) {

		System.out.println(m());

	}

	@SuppressWarnings("finally")
	public static int m() {

		try {
			System.out.println(1 / 0);
			return 1;
		} catch (Exception e) {
			// e.printStackTrace();
			return 2;
		} finally {
			try {
				return 3;
			} finally {
				return 4;
			}
			// return 5;
		}

	}

}
