package cn.tedu.exception;

public class ExceptionDemo5 {

	public static void main(String[] args) {

		try {
			System.out.println(1 / 0);
			System.out.println("try running~~~");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("finally running~~~");
		}

	}

}
