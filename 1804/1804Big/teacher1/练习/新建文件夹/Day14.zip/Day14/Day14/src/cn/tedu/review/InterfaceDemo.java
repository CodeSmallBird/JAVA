package cn.tedu.review;

public class InterfaceDemo {

	public static void main(String[] args) {

	}

}

interface Demo {

	void m1();

	default void m2() {
		System.out.println("m2");
	}

}