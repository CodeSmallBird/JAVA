package cn.tedu.exer.day08;

public class T301 {

}

class  MyClass {
	
	private static int count = 0;
	
	public MyClass() {
		count++;
	}

	public static int getCount(){
		return count;
	}
	
}
