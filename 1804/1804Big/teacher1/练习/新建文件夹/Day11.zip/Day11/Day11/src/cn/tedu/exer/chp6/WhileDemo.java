package cn.tedu.exer.chp6;

public class WhileDemo {

	public static void main(String[] args) {

		long begin = System.currentTimeMillis();

		// int sum = 0;
		// for (int i = 0; i <= 10000; i++) {
		// sum += i;
		// }
		int sum = sum(10000);
		System.out.println(sum);

		long end = System.currentTimeMillis();
		System.out.println(end - begin);
	}

	private static int sum(int n) {

		if (n <= 1)
			return 1;

		return n + sum(--n);
	}

}
