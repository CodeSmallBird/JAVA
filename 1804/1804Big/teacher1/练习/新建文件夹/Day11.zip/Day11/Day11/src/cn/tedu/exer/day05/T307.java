package cn.tedu.exer.day05;

public class T307 {

	public static void main(String[] args) {

		for (int abc = 100; abc < 1000; abc++) {
			if (square(abc)) {
				for (int xyz = 100; xyz < 1000; xyz++) {
					if (square(xyz)) {

						int a = abc / 100;
						int b = abc / 10 % 10;
						// int b = abc % 100 / 10;
						int c = abc % 10;

						int x = xyz / 100;
						int y = xyz / 10 % 10;
						int z = xyz % 10;

						if (square(10 * a + x) && square(10 * b + y) && square(10 * c + z)) {
							System.out.println(abc + "\t" + xyz);
						}

					}
				}
			}
		}

	}

	public static boolean square(int number) {

		int i = (int) Math.sqrt(number);

		return i * i == number;

	}

}
