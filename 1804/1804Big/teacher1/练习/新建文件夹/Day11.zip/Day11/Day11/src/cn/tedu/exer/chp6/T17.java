package cn.tedu.exer.chp6;

public class T17 {

}

class Role {

	String name;

	public int attack() {
		return 0;
	}

}

class Magicer extends Role {

	int level;

	public int attack() {
		return level * 5;
	}

}

class Soldier extends Role {

	int hurt;

	public int attack() {
		return hurt;
	}

}

class Team {

	Role[] rs = new Role[6];
	int count = 0;

	public void addMember(Role r) {

		if (count >= 6 && r == null)
			return;

		rs[count] = r;
		count++;
	}

	public int attackSum() {

		int sum = 0;
		for (int i = 0; i < count; i++) {
			sum += rs[i].attack();
		}

		return sum;

	}

}
