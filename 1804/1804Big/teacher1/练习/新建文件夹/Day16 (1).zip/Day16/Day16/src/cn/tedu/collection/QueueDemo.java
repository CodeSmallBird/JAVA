package cn.tedu.collection;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {

	public static void main(String[] args) {

		Queue<String> queue = new LinkedList<String>();
		
		// queue.add("a");
		// queue.add("d");
		// queue.add("c");
		// queue.add("w");

		// ����Ϊ�գ��򷵻�null
		System.out.println(queue.peek());
		// ����Ϊ�գ����׳�NoSuchElementException
		System.out.println(queue.element());

	}

}
