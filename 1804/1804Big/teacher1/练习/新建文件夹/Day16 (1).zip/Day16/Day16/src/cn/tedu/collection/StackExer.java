package cn.tedu.collection;

import java.util.EmptyStackException;

public class StackExer {

	public static void main(String[] args) {

		LinkedStack s = new LinkedStack();

		s.push("a");
		s.push("b");
		s.push("c");
		s.push("d");

		System.out.println(s.pop());

		System.out.println(s);

	}

}

class LinkedStack {

	private int size = 0;

	private Node first;

	@SuppressWarnings("unused")
	private Node last;

	public void push(String data) {

		Node node = new Node(null, data, null);

		if (size == 0) {
			first = node;
			last = node;
		} else {

			node.next = first;
			first.prev = node;
			first = node;

		}

		size++;

	}

	public String peek() {

		if (size == 0)
			throw new EmptyStackException();

		return first.data;

	}

	public String pop() {

		String data = peek();

		first = first.next;
		first.prev = null;

		size--;

		return data;

	}

	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder("[");

		Node node = first;

		for (int i = 0; i < size; i++) {
			sb.append(node.data).append(", ");
			node = node.next;
		}

		String str = sb.toString();

		if (size > 0) {
			str = str.substring(0, str.length() - 2);
		}

		return str += "]";

	}

	private class Node {

		@SuppressWarnings("unused")
		Node prev;
		String data;
		Node next;

		public Node(Node prev, String data, Node next) {
			super();
			this.prev = prev;
			this.data = data;
			this.next = next;
		}

	}

}