# if.py


# 本程序示意 if语句的用法

s = input("请输入: ")

i = int(s)  # 转为整数

if i != 0:
    print("您输入的是: ", s)


print("这是程序最后一条语句!!!")

