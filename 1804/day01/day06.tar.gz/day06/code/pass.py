
# pass 语句示例

s = input("请输入年龄：")
age = int(s)   # age绑定整数

if 0 <= age <= 120:
    pass
else:
    print("输入不合法")


