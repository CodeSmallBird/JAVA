
# 练习：
#   输入一个人的年龄:
#     如果年龄小于零提示: 输入不合法
#     如果年龄大于120提示: 输入不合法
#     否则提示: 输入年龄合法

s = input("请输入年龄：")
age = int(s)   # age绑定整数

# 方法1
# if age < 0 or age > 120:
#     print("输入不合法")
# else:
#     print("输入年龄合法")

# 方法2
# if age >= 0 and age <= 120:
#     print("输入年龄合法")
# else:
#     print("输入不合法")

# 方法 3
if 0 <= age <= 120:
    print("输入年龄合法")
else:
    print("输入不合法")


