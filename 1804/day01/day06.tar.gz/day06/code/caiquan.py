# 练习：
#   做游戏：
#     假设您与电脑做猜拳游戏，电脑出"石头"
#   您来选择输入:"石头", "剪刀", "布"
#   1) 石头
#   2) 剪刀
#   3) 布
#   请输入:
#     您输入1:  输出:平局，电脑是石头，您出的是石头
#     以下自己定义...
#   

computer = 1
print("1) 石头")
print("2) 剪刀")
print("3) 布")
s = input("请输入您要出什么？ ")
select = int(s)
if select == computer:
    print("平局，电脑是石头，您出的是石头")
elif select == 2:
    print("您输了，电脑是石头，您出的是剪刀")
elif select == 3:
    print("您赢了，电脑是石头，您出的是布")
else:
    print("您输入的有误!")


