
# file : shebao.py

# 练习：
#   输入一个人的北京社保基数(3082~23118)元：
# 计算这个人的五险一金

#   社保分为:
#      养老，医疗，失业，工伤，生育
#   一金:
#      公积金:
  
#       个人缴费比例     单位缴费比例 
# 养老       8%             19%
# 失业(城镇) 0.2%           0.8%
# 失业(农村)  0%            0.8%
# 工伤       0%            0.5%
# 生育       0%            0.8%
# 医疗       2%+3元         10%
# 公积金      12%           12%

# 要求:
#   写程序，输入您的社保基数，打印出各项要缴纳的费用明细和总和(公司部分总和和个人部分总和)

# ctrl + / 注释

s = input("请输入您的社保基数(3082~23118):")
base = int(s)  # 将社保基数字符串转换为整数

# 养老       8%             19%
yl_gr = base * 0.08
yl_qy = base * 0.19

is_chengzhen = input("是城镇户口(Y/n): ")
if is_chengzhen == 'Y':
    # 失业(城镇) 0.2%           0.8%
    sy_gr = base * 0.002
    sy_qy = base * 0.008
else:
    # 失业(农村)  0%            0.8%
    sy_gr = base * 0.000
    sy_qy = base * 0.008

# 工伤       0%            0.5%
gs_gr = 0
gs_qy = base * 0.005
# 生育       0%            0.8%
shengyu_gr = base * 0
shengyu_qy = base * 0.008
# 医疗       2%+3元         10%
yiliao_gr = base * 0.02 + 3
yiliao_qy = base * 0.1
# 公积金      12%           12%
gjj_gr = base * 0.12
gjj_qy = base * 0.12

print("       个人缴费比例     单位缴费比例 ")
print(" 养老     ", yl_gr, "   ", yl_qy)
if is_chengzhen == 'Y':
    print(" 失业(城镇)", sy_gr, "    ", sy_qy)
else:
    print(" 失业(农村) ", sy_gr, "    ", sy_qy)
print(" 工伤      ", gs_gr, "       ", gs_qy)
print(" 生育      ", shengyu_gr, "       ", shengyu_qy)
print(" 医疗      ", yiliao_gr, "   ", yiliao_qy)
print(" 公积金    ", gjj_gr, "   ", gjj_qy)


gr_xj = yl_gr + sy_gr + gs_gr + shengyu_gr + yiliao_gr + gjj_gr
qy_xj = yl_qy + sy_qy + gs_qy + shengyu_qy + yiliao_qy + gjj_qy
print("个人缴费小计: ", gr_xj)
print("企业缴费小计: ", qy_xj)

print("缴总费额： ", gr_xj + qy_xj)
