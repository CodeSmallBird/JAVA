# if_elif.py

print(" 1) 拳皇")
print(" 2) 魂斗罗")
print(" 3) 合金弹头")

s = input("请选择: ")
i = int(s)

if i == 1:
    print("开始进入拳皇...")
elif i == 2:
    print("开始进入魂斗罗...")
elif i == 3:
    print("开始进入合金弹头...")
else:
    print("您的选择在菜单中不存在")



