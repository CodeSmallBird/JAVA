# not.py

s = input("请输入一个整数:")
n = int(s)

if not n > 0:  # if n <= 0:
    print("n 不大于 0")

    